<?php
$id = $_POST["id"];
$name = $_POST["name"];
$email = $_POST["email"];
$age = $_POST["age"];
$gender = $_POST["gender"];
$phone = $_POST["phone"];
$username = $_POST["username"];

include("dbConnect.php");
$response["success"]=false;


if(isset($_POST["pass"])){

$new_password = $_POST["pass"];
    
    $result2 = mysqli_query($conn,"UPDATE `user` SET `name` = '$name' ,`email` = '$email',`password`='$new_password',`username`='$username',`phone`='$phone',`age`='$age',`gender`='$gender' WHERE `userId`='$id'");
    
	$check1 = mysqli_affected_rows($conn);
	if($check1 > 0){
	$response["success"]=true;
	}
}
else{
			
			    $result3 = mysqli_query($conn,"UPDATE `user` SET `name` = '$name' ,`email` = '$email',`username`='$username',`phone`='$phone',`age`='$age',`gender`='$gender' WHERE `userId`='$id'");
    $check2 = mysqli_affected_rows($conn);
	
	if($check2 > 0){
	$response["success"]=true;
	}
}

echo json_encode($response);
mysqli_close($conn);
exit();
?>