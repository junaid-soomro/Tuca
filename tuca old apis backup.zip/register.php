<?php
$password = $_POST["password"];
$email = $_POST["email"];
$name = $_POST["name"];
$gender = $_POST["gender"];
$phone = $_POST["phone"];
$age = $_POST["age"];
$username = $_POST["username"];


include("dbConnect.php");
$response=array();
$response["success"]=false;
$check=mysqli_query($conn,"SELECT * FROM `user` WHERE `Email`='$email'");
$affected=mysqli_affected_rows($conn);
if($affected>0){
  $response["status"]="USERNAME";
}
else{
  
  $result=mysqli_query($conn,"INSERT INTO `user` (`name`, `password`, `email`, `gender`,`phone`,`age`,`username`) VALUES ('$name', '$password', '$email', '$gender','$phone','$age','$username')");
  
  $response["success"]=true;
}
echo json_encode($response);#encoding RESPONSE into a JSON and returning.
mysqli_close($conn);
exit();
?>