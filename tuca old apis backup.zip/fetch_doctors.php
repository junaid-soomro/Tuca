<?php
include("dbConnect.php");

$clinic_id = $_POST["clinic_id"];

$response=array();

$query = mysqli_query($conn,"SELECT * FROM `doctor` WHERE `isDelete`='0' AND `clinicId`='$clinic_id'");

while($row = MYSQLI_FETCH_ASSOC($query) ){
    
    array_push($response,array("doctor_id"=>$row["doctorId"],"doctor_name"=>$row["name"]));
    
	}

echo json_encode($response);
mysqli_close($conn);
exit();
?>