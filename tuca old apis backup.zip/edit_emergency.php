<?php
$id = $_POST["id"];
$name=$_POST["name"];
$username = $_POST["username"];

include("dbConnect.php");
$response["success"]=false;


if(isset($_POST["pass"])){

$new_password = $_POST["pass"];
    
    $result2 = mysqli_query($conn,"UPDATE `emergency` SET `e_name` = '$name' ,`e_password`='$new_password',`e_username`='$username' WHERE `e_id`='$id'");
    
	$check1 = mysqli_affected_rows($conn);
	if($check1 > 0){
	$response["success"]=true;
	}
}
else{
			
			   $result2 = mysqli_query($conn,"UPDATE `emergency` SET `e_name` = '$name',`e_username`='$username' WHERE `e_id`='$id'");
    $check2 = mysqli_affected_rows($conn);
	
	if($check2 > 0){
	$response["success"]=true;
	}
}

echo json_encode($response);
mysqli_close($conn);
exit();
?>