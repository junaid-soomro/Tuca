<?php
include("dbConnect.php");
$response=array();

$query = mysqli_query($conn,"SELECT * FROM `clinic` WHERE `isDelete`='0'");

while($row = MYSQLI_FETCH_ASSOC($query) ){
    
    array_push($response,array("clinic_id"=>$row["clinicId"],"clinic_name"=>$row["name"]));
    
	}

echo json_encode($response);
mysqli_close($conn);
exit();
?>