<?php
include("dbConnect.php");

$response["status"]=false;

$status = $_POST["status"];
$id = $_POST["req_id"];

mysqli_query($conn,"UPDATE `emergency_requests` SET `req_status`='$status' WHERE `req_id`='$id'");

$check = mysqli_affected_rows($conn);
if($check>0){
$response["status"]=true;
}

echo json_encode($response);
mysqli_close($conn);
exit();
?>