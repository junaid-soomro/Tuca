<?php
include("dbConnect.php");

if(isset($_POST["name"])){
    $response["status"]=false;
    
    $name = $_POST["name"];
    $lat = $_POST["lat"];
    $lon = $_POST["lon"];
    
    mysqli_query($conn,"INSERT INTO `emergency_requests` (`lat`,`lon`,`patient_name`)VALUES('$lat','$lon','$name')");
    
    $check = mysqli_affected_rows($conn);
    if($check>0){
        
        $response["status"]=true;
    }
}else{
    
    $response = array();
    $query = mysqli_query($conn,"SELECT * FROM `emergency_requests` WHERE `req_status`='pending'");
    
    while($row = MYSQLI_FETCH_ASSOC($query)){
        
        array_push($response,array("req_id"=>$row["req_id"],"lat"=>$row["lat"],"lon"=>$row["lon"],"name"=>$row["patient_name"]));
    }
    
}

echo json_encode($response);
mysqli_close($conn);
exit();

?>