<?php
include("dbConnect.php");
//book appointment
if(isset($_POST["patient_id"])){
$response["status"]=false;
$id = $_POST["patient_id"];
$date = $_POST["date"];
$time = $_POST["time"];
$doc = $_POST["doc_id"];

mysqli_query($conn,"INSERT INTO `appointments` (`patient_id`,`time`,`date`,`doc_id`)VALUES('$id','$time','$date','$doc')");

$check = mysqli_affected_rows($conn);
if($check > 0){
$response["status"]=true;	
	}
}
//fetch history appointments
else if($_POST["history_id"]){

$response=array();
$id = $_POST["history_id"];
	
$query = mysqli_query($conn,"SELECT `patient_id`,user.name,`date`,schedule.time,`appoint_status` FROM `appointments` INNER JOIN `user` INNER JOIN `schedule` ON(appointments.patient_id=user.userId) AND(appointments.time=schedule.schedule_id) WHERE `appoint_status`='pending' AND `patient_id`='$id'");	
	
	while($row = MYSQLI_FETCH_ASSOC($query)){
		array_push($response,array("name"=>$row["name"],"date"=>$row["date"],"time"=>$row["time"],"status"=>$row["appoint_status"]));
	}
	
}
//fetch all appointments code
else{
	
}
echo json_encode($response);
mysqli_close($conn);
exit();

?>