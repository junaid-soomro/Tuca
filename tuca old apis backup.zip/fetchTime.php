<?php
include("dbConnect.php");

$response = array();
    
    $que = mysqli_query($conn,"SELECT * FROM `schedule`");
    
    while($row = MYSQLI_FETCH_ASSOC($que)){
        
        array_push($response,array(
            "sc_id"=>$row["schedule_id"],"time"=>$row["time"]));
    }
    
    

echo json_encode($response);
mysqli_close($conn);
exit();
?>