<?php
$conn = mysqli_connect('localhost','tuca','tuca12345','tuca') or die("Unable to connect");
?>